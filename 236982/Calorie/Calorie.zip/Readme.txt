Compile program with any C++ compiler.
for example Mingw: 
g++ *.cpp -o CalorieTracker